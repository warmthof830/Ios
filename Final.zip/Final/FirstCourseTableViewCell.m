//
//  FirstCourseTableViewCell.m
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "FirstCourseTableViewCell.h"

@implementation FirstCourseTableViewCell
{
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}







@end
