//
//  FirstCourseViewController.m
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "FirstCourseViewController.h"
#import "FirstCourseTableViewCell.h"
#import "PractiseSelectViewController.h"
#import "FMDB.h"
#import "FirstLevel.h"
#import "PractiseViewController.h"
#import "LeafLevel.h"
#import "chuan.h"


@interface FirstCourseViewController () <UITableViewDelegate,UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation FirstCourseViewController
{
    FirstCourseTableViewCell *cell;
    NSDictionary *practiceDic;
    NSMutableArray *dataArray;
    FMDatabase *dataBase;
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView setScrollEnabled:NO];
    
    
    practiceDic = [NSDictionary dictionaryWithObjectsAndKeys:@"Test (60 minutes, 10 questions)",@"7",@"Randomly Practice",@"8",@"All Questions",@"10",@"Practice by Chapter",@"11",nil];
    dataArray = [[NSMutableArray alloc]init];
    
    [self createDateBase];
    
    [self setExtraCellLineHidden:self.tableView];
    
}

#pragma open database
-(BOOL)createDateBase
{
    NSString *sqlitePath = [[NSBundle mainBundle]pathForResource:@"data" ofType:@"sqlite"];
    dataBase = [FMDatabase databaseWithPath:sqlitePath];
    
    if (![dataBase open]) {
        NSLog(@"create dataBase fail...");
        return NO;
    }
    return YES;
}

-(void)setExtraCellLineHidden: (UITableView *)tableView
{
    UIView *view = [UIView new];
    view.backgroundColor = [UIColor clearColor];
    [tableView setTableFooterView:view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return  practiceDic.count;
    
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    cell = [self.tableView dequeueReusableCellWithIdentifier:@"firstCourse"];
    if(cell == nil){
        // cell
        [self.tableView registerNib:[UINib nibWithNibName:@"FirstCourseTableViewCell" bundle:nil] forCellReuseIdentifier:@"firstCourse"];
        
        cell = [self.tableView dequeueReusableCellWithIdentifier:@"firstCourse"];
    }
    NSArray *keysArray = [practiceDic allKeys];//store in array
    NSArray *sortedArray = [keysArray sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2){
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];//sequence
    NSString *key = sortedArray[indexPath.row];
    
    [cell.imageBtn setBackgroundImage:[UIImage imageNamed:key] forState:UIControlStateNormal];
    cell.IntroduceLabel.text = [practiceDic objectForKey:key];
    
    
    return cell;
    
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"%ld",(long)indexPath.row);
    if (indexPath.row == 3.0) {
        [chuan shareInstance].contextStr=@"0";
        [self performSegueWithIdentifier:@"practiseSelect" sender:indexPath];
    }else if(indexPath.row == 2.0){
        [chuan shareInstance].contextStr=@"0";
        [self performSegueWithIdentifier:@"practise" sender:indexPath];
    }else if(indexPath.row == 1.0){
        [chuan shareInstance].contextStr=@"0";
        [self performSegueWithIdentifier:@"practise" sender:indexPath];
    }
    else if(indexPath.row == 0){
        [chuan shareInstance].contextStr=@"1";
        [self performSegueWithIdentifier:@"practise" sender:indexPath];

        
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    PractiseSelectViewController *practiseSelectView = [segue destinationViewController];
    
    PractiseViewController *practiseView = [segue destinationViewController];
    
    NSIndexPath *index = sender;
    if (index.row == 3.0) {
        dataArray = [self queryPractiseSelectSql:@"select * from firstlevel"];
        [practiseSelectView setValue:dataArray forKey:@"dataArray"];
        [practiseSelectView setValue:@"Practice by Chapter" forKey:@"courseTitle"];
    }else if (index.row == 2.0){
        dataArray = [self queryPractiseSql:@"select * from leafLevel"];
        [practiseView setValue:dataArray forKey:@"practiseArray"];
        [practiseView setValue:@"All Questions" forKey:@"courseTitle"];
    }
    else if(index.row == 1.0){
        NSMutableArray*temArr=[[NSMutableArray alloc]init];
        NSArray*array=[self queryPractiseSql:@"select * from leafLevel"];
        //NSMutableArray*dataArr=[[NSMutableArray alloc]init];
        [temArr addObjectsFromArray:array];
        for(int i=0;i<temArr.count;){
            int index =arc4random()%(temArr.count);
            [dataArray addObject:temArr[index]];
            [temArr removeObjectAtIndex:index];
            
        }
        [practiseView setValue:dataArray forKey:@"practiseArray"];
        [practiseView setValue:@"Randomly Practice" forKey:@"courseTitle"];

    }
    else if(index.row == 0){
        NSMutableArray*temArr=[[NSMutableArray alloc]init];
        NSArray*array=[self queryPractiseSql:@"select * from leafLevel"];
        //NSMutableArray*dataArr=[[NSMutableArray alloc]init];
        [temArr addObjectsFromArray:array];
        for(int i=0;i<10;i++){
            int index =arc4random()%(temArr.count);
            [dataArray addObject:temArr[index]];
            [temArr removeObjectAtIndex:index];
            
        }
        [practiseView setValue:dataArray forKey:@"practiseArray"];
        [practiseView setValue:@"Time" forKey:@"courseTitle"];


               
    }
    
    
}


//-(void)creatNavBtn{
//    
//    UIBarButtonItem*itemLeft=[[UIBarButtonItem alloc]init];
//    PractiseViewController*v=[[PractiseViewController alloc]init];
//    itemLeft.title=@"Back";
//    [itemLeft setTarget:v];
//    [itemLeft setAction:@selector(clickNavBtnReturn)];
//    self.navigationItem.leftBarButtonItem=itemLeft;
//    UIBarButtonItem*itemRight=[[UIBarButtonItem alloc]init];
//    itemRight.title=@"Finish";
//    [itemRight setTarget:v];
//    [itemRight setAction:@selector(clickRightItem)];
//    self.navigationItem.rightBarButtonItem=itemRight;
//}
-(void)clickRightItem{
    UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"Notice" message:@"Are you sure you finish the test?" delegate:self cancelButtonTitle:@"No, continue test" otherButtonTitles:@"Yes, I finish", nil];
    [alert show];
}
-(void)clickNavBtnReturn{
    UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"Notice" message:@"Are you sure you want to leave test?" delegate:self cancelButtonTitle:@"No, continue test" otherButtonTitles:@"Yes", nil];
    [alert show];
}
-(void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            break;
        case 1:
        {
            [self.navigationController popoverPresentationController];
        }
        default:
            break;
    }
}
#pragma 获取数据
-(NSMutableArray *)queryPractiseSelectSql:(NSString *)sql
{
    
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    if ([dataBase open]) {
        
        FMResultSet *rs = [dataBase executeQuery:sql];
        
        while([rs next]){
            FirstLevel *firstLevel = [[FirstLevel alloc]init];
            firstLevel.pId = [rs intForColumn:@"pid"];
            firstLevel.pName = [rs stringForColumn:@"pname"];
            firstLevel.pCount = [rs intForColumn:@"pcount"];
            [arr addObject:firstLevel];
        }
    }
    [dataBase close];
    return arr;
}

-(NSMutableArray *)queryPractiseSql:(NSString *)sql
{
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    if ([dataBase open]) {
        
        FMResultSet *rs = [dataBase executeQuery:sql];
        
        while([rs next]){
            LeafLevel *leafLevel = [[LeafLevel alloc]init];
            leafLevel.mQuestion = [rs stringForColumn:@"mquestion"];
            leafLevel.mDesc = [rs stringForColumn:@"mdesc"];
            leafLevel.mId = [rs intForColumn:@"mid"];
            leafLevel.mAnswer = [rs stringForColumn:@"manswer"];
            leafLevel.mImage = [rs stringForColumn:@"mimage"];
            leafLevel.pId = [rs intForColumn:@"pid"];
            leafLevel.pName = [rs stringForColumn:@"pname"];
            leafLevel.sId = [rs intForColumn:@"sid"];
            leafLevel.sName = [rs stringForColumn:@"sname"];
            leafLevel.mStatus = [rs intForColumn:@"mstatus"];
            leafLevel.mArea = [rs stringForColumn:@"marea"];
            leafLevel.mType = [rs intForColumn:@"mtype"];
            leafLevel.mUnknow = [rs stringForColumn:@"munknow"];
            leafLevel.mYear = [rs intForColumn:@"myear"];
            leafLevel.eCount = [rs intForColumn:@"ecount"];
            [arr addObject:leafLevel];
        }
    }
    [dataBase close];
    return arr;

}





/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
