//
//  FirstLevel.h
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FirstLevel : NSObject

@property (nonatomic, assign) int pId;
@property (nonatomic, copy  ) NSString  *pName;
@property (nonatomic, assign) int pCount;

@end
