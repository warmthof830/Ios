//
//  LeafLevel.h
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LeafLevel : NSObject

@property (nonatomic, copy  ) NSString  *mQuestion;  //question
@property (nonatomic, copy  ) NSString  *mDesc;
@property (nonatomic, assign) NSInteger mId;   
@property (nonatomic, copy  ) NSString  *mAnswer;
@property (nonatomic, copy  ) NSString  *mImage;
@property (nonatomic, assign) NSInteger pId;
@property (nonatomic, copy  ) NSString  *pName;
@property (nonatomic, assign) NSInteger sId;    //
@property (nonatomic, strong) NSString  *sName;
@property (nonatomic, assign) NSInteger mStatus;
@property (nonatomic, copy  ) NSString  *mArea;
@property (nonatomic, assign) NSInteger mType;
@property (nonatomic, strong) NSString  *mUnknow;
@property (nonatomic, assign) NSInteger mYear;
@property (nonatomic, assign) NSInteger eCount;

@end
