//
//  LoginViewController.h
//  Final
//
//  Created by XuanGao on 4/28/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *nameTxt;
@property (strong, nonatomic) IBOutlet UITextField *passTxt;

@end
