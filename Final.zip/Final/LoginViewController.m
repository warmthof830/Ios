//
//  LoginViewController.m
//  Final
//
//  Created by XuanGao on 4/28/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()
@property (strong, nonatomic) IBOutlet UIButton *logBtn;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=@"Log In";
    // Do any additional setup after loading the view.
}
- (IBAction)logClick:(id)sender {
    if(!_nameTxt.hasText||!_passTxt.hasText){
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Please enter the information!" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
        
        [alert show];
    }else{
        if(![_nameTxt.text isEqual:@"gaoxuan"]||![_passTxt.text isEqual:@"111111"]){
            UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Wrong name or password" delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
            
            [alert show];
            
        }
        else{
            NSString*a=@"Hello, ";
            NSString*b=[NSString stringWithFormat:@"%@",_nameTxt.text];
            NSString*message=[[NSString alloc]initWithFormat:@"%@ %@", a,b];
            UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"Welcome to the NEU Test System!" message:message delegate:self cancelButtonTitle:@"ok" otherButtonTitles: nil];
            
            [alert show];
            [self performSegueWithIdentifier:@"test" sender:self];
            
            
        }

    }
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
