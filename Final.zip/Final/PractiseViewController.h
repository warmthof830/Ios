//
//  PractiseViewController.h
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PractiseViewController : UIViewController
{
    @public
    UIScrollView *_scrollView;
}
@property(nonatomic,strong)NSMutableArray *hadAnswerArray;
@property(nonatomic,strong)NSArray* dataArray;
-(void)sheetViewClick:(int)index;

@end
