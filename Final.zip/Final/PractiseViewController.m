//
//  PractiseViewController.m
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "PractiseViewController.h"
#import "PractiseTableViewCell.h"
#import "LeafLevel.h"
#import "Tools.h"
#import "StatisticsView.h"
#import "SelectModelView.h"
#import "SheetView.h"
#import "FirstCourseViewController.h"
#import "chuan.h"
#import "QuestionCollect.h"

#define kScreenX [UIScreen      mainScreen].bounds.size.width
#define kScreenY [UIScreen      mainScreen].bounds.size.height

@interface PractiseViewController ()<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,SheetViewDelegate>
{
    SelectModelView*modelView;
    SheetView*_sheetView;
}
@property (nonatomic, strong) NSMutableArray *practiseArray;
@property (nonatomic, strong) NSString *courseTitle;
@property (nonatomic, assign,readonly) int currentPage;
@end

@implementation PractiseViewController
{
    UITableView *_leftTableView;
    UITableView *_centreTableView;
    UITableView *_rightTableView;
    //UIScrollView *_scrollView;
    int headHeigt;
    Tools *tools;
    NSMutableArray *_answerArr;
    UIToolbar *_footToolBar;
   // StatisticsView *_sheetView;
    UIButton *toolsBtn;
    UILabel *toolsLabel;
    NSTimer*_timer;
    UILabel*_timeLabel;
    
    
}
#pragma mark - delegate
-(void)sheetViewClick:(int)index{
    NSLog(@"%d",index);
    UIScrollView*scroll=self->_scrollView;
    scroll.contentOffset=CGPointMake((index-1)*_scrollView.frame.size.width, 0);
    [scroll.delegate scrollViewDidEndDecelerating:scroll];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initWithSub];
    _leftTableView.delegate     = self;
    _leftTableView.dataSource   = self;
    _centreTableView.delegate   = self;
    _centreTableView.dataSource = self;
    _rightTableView.delegate    = self;
    _rightTableView.dataSource  = self;
    
    _scrollView.delegate = self;
    
    self.navigationItem.title = self.courseTitle;

    
    NSLog(@"%@",[chuan shareInstance].contextStr);
    if([[chuan shareInstance].contextStr isEqual:@"1"]){
    UIBarButtonItem*itemLeft=[[UIBarButtonItem alloc]init];
    itemLeft.title=@"Back";
    [itemLeft setTarget:self];
    [itemLeft setAction:@selector(clickNavBtnReturn)];
    self.navigationItem.leftBarButtonItem=itemLeft;
    
    UIBarButtonItem*itemRight=[[UIBarButtonItem alloc]init];
    itemRight.title=@"Finish";
    [itemRight setTarget:self];
    [itemRight setAction:@selector(clickRightItem)];
        self.navigationItem.rightBarButtonItem=itemRight;
        _timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(runTime) userInfo:nil repeats:YES];
        _timeLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 100, 64)];
        _timeLabel.text=@"60:00";
        _timeLabel.textColor=[UIColor whiteColor];
        _timeLabel.textAlignment=NSTextAlignmentCenter;
        self.navigationItem.titleView=_timeLabel;
        
    
    }
    
    
    _answerArr = [[NSMutableArray alloc]init ];
    for(int i=0;i<_practiseArray.count;i++){
        [_answerArr addObject:@"0"];
    }
    
    _currentPage = 0;
    
}
-(void)runTime{
    static int Time=3600;
    Time--;
    _timeLabel.text=[NSString stringWithFormat:@"%d:%d",Time/60,Time%60];
}
-(void)clickRightItem{
   UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"Notice" message:@"Are you sure you finish the test?" delegate:self cancelButtonTitle:@"No, continue test" otherButtonTitles:@"Yes, I finish", nil];
    [alert show];
}
-(void)clickNavBtnReturn{
    UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"Notice" message:@"Are you sure you want to leave test?" delegate:self cancelButtonTitle:@"No, continue test" otherButtonTitles:@"Yes", nil];
    [alert show];
}
-(void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"%ld",(long)buttonIndex);
    switch (buttonIndex) {
        case 0:
            break;
        case 1:
        {
            NSString*a=@"Your Final Grade is ";
            NSMutableArray *array2 = [NSMutableArray array];
            for (NSString *str in [QuestionCollect getWrongQuestion]) {
                if (![array2 containsObject:str]) {
                    [array2 addObject:str];
                }
            }
            NSString*b=[NSString stringWithFormat:@"%lu",100-(unsigned long)array2.count];
            NSString*message=[[NSString alloc]initWithFormat:@"%@ %@", a,b];
            UIAlertView*alert=[[UIAlertView alloc]initWithTitle:@"Notice" message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alert show];
            [self.navigationController popViewControllerAnimated:YES];
        }
        default:
            break;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}



-(void)initWithSub
{
    _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, kScreenX, kScreenY-60)];
    // _scrollView.frame = CGRectMake(0, 0, kScreenX, kScreenY);
    
    tools = [[Tools alloc]init];
    
    if (self.practiseArray.count >1) {
        _scrollView.contentSize = CGSizeMake(kScreenX*2, 0);
    }
    
    //_scrollView.contentSize=CGSizeMake(kScreenX*3,0);
    
    _leftTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenX, kScreenY) style:UITableViewStyleGrouped];
    _centreTableView = [[UITableView alloc]initWithFrame:CGRectMake(kScreenX, 0, kScreenX, kScreenY) style:UITableViewStyleGrouped];
    _rightTableView = [[UITableView alloc]initWithFrame:CGRectMake(kScreenX*2, 0, kScreenX, kScreenY) style:UITableViewStyleGrouped];

    //    _leftTableView.backgroundColor = [UIColor blueColor];
    //    _centreTableView.backgroundColor = [UIColor greenColor];
    //    _rightTableView.backgroundColor = [UIColor redColor];
    
 
    [_leftTableView setScrollEnabled:NO];
    [_centreTableView setScrollEnabled:NO];
    [_rightTableView setScrollEnabled:NO];
    

    _scrollView.pagingEnabled = YES;

    _scrollView.bounces = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;

    // _scrollView.contentOffset = CGPointMake(0, 0);
    //_scrollView.delaysContentTouches=NO;
   
    
    [_scrollView addSubview:_leftTableView];
    [_scrollView addSubview:_centreTableView];
    [_scrollView addSubview:_rightTableView];
    [self.view addSubview:_scrollView];
    
    [self creatModelView];
    [self createToolBar];
   
    [self creatSheetView];
}


-(void)creatModelView{
    modelView=[[SelectModelView alloc]initWithFrame:self.view.frame addTouch:^(SelectModel model){
        NSLog(@"current model:%d",model);}];
    [self.view addSubview:modelView];
    modelView.alpha=0;
    UIBarButtonItem*item=[[UIBarButtonItem alloc]initWithTitle:@"Model" style:UIBarButtonItemStylePlain target:self action:@selector(modelChange:)];
    self.navigationItem.rightBarButtonItem=item;
}
-(void)modelChange:(UIBarButtonItem*)item{
    [UIView animateWithDuration:0.3 animations:^{modelView.alpha=1;}];
}
#pragma toolbar
-(void)createToolBar
{
    UIView *barView = [[UIView alloc]initWithFrame:CGRectMake(0, kScreenY-60, kScreenX, 60)];
    barView.backgroundColor = [UIColor lightGrayColor];
    NSArray *arr = @[@"Menu",@"Favorite"];
   //* for(int i= 0; i<arr.count;i++){
        for(int i= 0; i<2;i++){
        toolsBtn = [[UIButton alloc]initWithFrame:CGRectMake(kScreenX/2*i+kScreenX/2/2-22, 0, 40, 40)];
        [toolsBtn setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d",16+i]] forState:UIControlStateNormal];
        [toolsBtn setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d-2",16+i]] forState:UIControlStateHighlighted];
        [toolsBtn setTag:100+i];
        [toolsBtn addTarget:self action:@selector(selectorBtn:) forControlEvents:UIControlEventTouchUpInside];
        
        toolsLabel = [[UILabel alloc]initWithFrame:CGRectMake(toolsBtn.center.x-30,40, 60, 20)];
        toolsLabel.text=  arr[i];
        toolsLabel.textAlignment = NSTextAlignmentCenter;
        toolsLabel.font = [UIFont systemFontOfSize:14];
        [barView addSubview:toolsBtn];
        [barView addSubview:toolsLabel];
    
    }
    [self.view addSubview:barView];
}

//-(void)createSheetView
//{
//    _sheetView = [[StatisticsView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height-150) withSuperView:self.view];
//    [self.view addSubview:_sheetView];
//}
-(void)creatSheetView{
    _sheetView=[[SheetView alloc]initWithFrame:CGRectMake(0, kScreenY, kScreenX, kScreenY-150)withSuperView:self.view andQuesCount:self.practiseArray.count];
    _sheetView.delegate=self;
    [self.view addSubview:_sheetView];
}
-(void)selectorBtn:(UIButton *)sender
{
    int tag = (int)sender.tag;
    
    //UIView *view;
    switch (tag) {
        case 100:
        {
            [UIView animateWithDuration:0.3 animations:^{
                _sheetView.frame = CGRectMake(0, 150, self.view.frame.size.width, self.view.frame.size.height-150);
                _sheetView->_backView.alpha=0.8;
            }];
        }
           //[[StatisticsView alloc]initWithFrame:self.view.frame withSuperView:self.view];
            //[self.view addSubview:view];
            break;
        case 102:
        {
            if([_answerArr[_currentPage] intValue]!=0){
                return;
            }else{
                
                LeafLevel*l=[_practiseArray objectAtIndex:_currentPage];
                NSString* answer=l.mAnswer;
                NSLog(@"%@",answer);
                char an=[answer characterAtIndex:0];
                
                [_answerArr replaceObjectAtIndex:_currentPage withObject:[NSString stringWithFormat:@"%d",an-'A'+1]];
                [self reloadData];

            }
            break;
        case 101:
            {
                [QuestionCollect addCollectQuestion:_currentPage+1];
                NSLog(@"%@",[QuestionCollect getCollectQuestion]);
            }
            break;
        }
        default:
            break;
    }

}




-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGPoint currentOffSet = _scrollView.contentOffset;
    int page = (int)currentOffSet.x/kScreenX;
    //NSLog(@"%d",page);
    if (page<self.practiseArray.count-1 && page >0) {
        _scrollView.contentSize = CGSizeMake(currentOffSet.x+kScreenX*2, 0);
        _centreTableView.frame = CGRectMake(currentOffSet.x, 0, kScreenX, kScreenY);
        _leftTableView.frame = CGRectMake(currentOffSet.x-kScreenX, 0, kScreenX, kScreenY);
        _rightTableView.frame = CGRectMake(currentOffSet.x+kScreenX, 0, kScreenX, kScreenY);
    }
    
    _currentPage = page;
    
    
    
    [self reloadData];
}

//refresh
-(void)reloadData
{
    [_leftTableView reloadData];
    [_centreTableView reloadData];
    [_rightTableView reloadData];
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    LeafLevel *leafLevel = _practiseArray[_currentPage];
    if(leafLevel.mType == 2){
        return 2;
    }else{
        return 4;
    }
    
}


-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    UILabel *label = [self getQuestion:tableView];
    
    
    return label.frame.size.height;
    
    
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    
    UILabel *label = [self getQuestion:tableView];
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, label.frame.size.width, label.frame.size.height)];
    
    view.backgroundColor = [UIColor colorWithWhite:0.947 alpha:1.000];
    
    [view addSubview:label];
    
    
    
    return view;
    
    
}


-(UILabel *)getQuestion:(UITableView *)tableView
{
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 0, 0)];
    LeafLevel *leafLevel;
    //if it is first page
    
    if(tableView == _leftTableView && _currentPage == 0){
        leafLevel = _practiseArray[_currentPage];
    }else if(tableView ==_leftTableView && _currentPage>0){
        leafLevel = _practiseArray[_currentPage-1];
    }else if(tableView == _centreTableView && _currentPage == 0 ){
        leafLevel = _practiseArray[_currentPage+1];
    }else if(tableView == _centreTableView && _currentPage>0 && _currentPage<_practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage];
    }else if(tableView == _centreTableView && _currentPage == _practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage-1];
    }else if(tableView == _rightTableView && _currentPage == _practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage];
    }else if(tableView == _rightTableView && _currentPage<_practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage+1];
    }
    int page = [self getPage:tableView andCurrentpage:_currentPage];
    
    label.textColor = [UIColor blackColor];
    label.numberOfLines = 0;
    label.font = [UIFont systemFontOfSize:18];
    label.textAlignment = NSTextAlignmentLeft;
    CGSize size;
    if (leafLevel.mType == 1) {
        
        label.text = [NSString stringWithFormat:@"%d.%@",page,[[tools getAnsWerWithString:leafLevel.mQuestion]objectAtIndex:0]];
        
        size = [tools sizeWithString:[[tools getAnsWerWithString:leafLevel.mQuestion]objectAtIndex:0] font:label.font];
        
    }else if(leafLevel.mType == 2){
        label.text = [NSString stringWithFormat:@"%d.%@",page,leafLevel.mQuestion];
        size =[tools sizeWithString:leafLevel.mQuestion font:label.font];
        
    }
    
    
    label.frame = CGRectMake(10, 0,kScreenX,  size.height+50);
    
    NSLog(@"%d --- %f",page+1,size.height);
    return  label;
    
}



-(int )getPage:(UITableView *)tableView andCurrentpage:(int) currentPage
{
    
    //first page
    int page = 0;
    if(tableView == _leftTableView && currentPage == 0){
        page = currentPage+1;
    }else if(tableView ==_leftTableView && currentPage>0){
        page = currentPage;
    }else if(tableView == _centreTableView && currentPage == 0 ){
        page = currentPage+2;
    }else if(tableView == _centreTableView && currentPage>0 && currentPage<_practiseArray.count-1){
        page = currentPage+1;
    }else if(tableView == _centreTableView && currentPage == _practiseArray.count-1){
        page = currentPage;
    }else if(tableView == _rightTableView && currentPage == _practiseArray.count-1){
        page = currentPage+1;
    }else if(tableView == _rightTableView && currentPage<_practiseArray.count-1){
        page = currentPage+2;
    }
    return page;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    return 60;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    PractiseTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"practiseCell"];
    if(cell == nil){

        [tableView registerNib:[UINib nibWithNibName:@"PractiseTableViewCell" bundle:nil] forCellReuseIdentifier:@"practiseCell"];
        cell = [tableView dequeueReusableCellWithIdentifier:@"practiseCell"];
        
        
    }
    
    LeafLevel *leafLevel = [self getModel:tableView];
    
    
    cell.answerLabel.layer.masksToBounds = YES;
    cell.answerLabel.layer.cornerRadius = 20;
    
    cell.answerLabel.text = [NSString stringWithFormat:@"%c",(char)('A'+indexPath.row)];
    
    
    
    cell.IntroduceLabel.font = [UIFont systemFontOfSize:18];
    
    //question type
    if (leafLevel.mType ==1) {
        cell.IntroduceLabel.text = [[tools getAnsWerWithString:leafLevel.mQuestion]objectAtIndex:indexPath.row+1];
        //cell.in
        CGSize size = [tools sizeWithString:cell.IntroduceLabel.text font:cell.IntroduceLabel.font];
        cell.frame = CGRectMake(0, 0, kScreenX, size.height);
        
    }else if(leafLevel.mType == 2){
        if(indexPath.row == 0){
            cell.IntroduceLabel.text = @"correct";
        }else if(indexPath.row == 1){
            cell.IntroduceLabel.text = @"wrong";
        }
        
    }
    
    //wrong or correct
    int page = [self getPage:tableView andCurrentpage:_currentPage];
    if (leafLevel.mType ==1) {
        if ([_answerArr[page-1] intValue] != 0) {
            if([leafLevel.mAnswer isEqualToString:[NSString stringWithFormat:@"%c",'A'+(int)indexPath.row]]){
                //cell.answerLabel.hidden = YES;
                cell.image.image=nil;
                cell.image.hidden = NO;
                cell.image.image = [UIImage imageNamed:@"19"];
            }else if(![leafLevel.mAnswer isEqualToString:[NSString stringWithFormat:@"%c",'A'+[_answerArr[page-1]intValue]-1]]
                     &&indexPath.row == [_answerArr[page-1] intValue]-1){
                //cell.answerLabel.hidden = YES;
                cell.image.image=nil;
                cell.image.hidden = NO;
                cell.image.image = [UIImage imageNamed:@"20"];
            }else{
                //cell.answerLabel.hidden = NO;
                cell.image.hidden = YES;
            }
        }else{
            //cell.answerLabel.hidden = NO;
            cell.image.hidden = YES;
            
        }
    }else{
        if ([_answerArr[page-1] intValue] != 0) {
            if([leafLevel.mAnswer isEqualToString:[NSString stringWithFormat:@"%c",'0'+(int)indexPath.row]]){
                //cell.answerLabel.hidden = YES;
                cell.image.image=nil;
                cell.image.hidden = NO;
                cell.image.image = [UIImage imageNamed:@"19"];
            }else if(![leafLevel.mAnswer isEqualToString:[NSString stringWithFormat:@"%c",'0'+[_answerArr[page-1]intValue]-1]]
                     &&indexPath.row == [_answerArr[page-1] intValue]-1){
                //cell.answerLabel.hidden = YES;
                cell.image.image=nil;
                cell.image.hidden = NO;
                cell.image.image = [UIImage imageNamed:@"20"];
            }else{
                //cell.answerLabel.hidden = NO;
                cell.image.hidden = YES;
            }
        }else{
            //cell.answerLabel.hidden = NO;
            cell.image.hidden = YES;
            
        }
        
    }
    

    
    
    
    
    // cell.image.image = [UIImage imageNamed:@"19"];
    //cell.answerLabel.hidden = YES;
    
    
    
    
    return cell;
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    int page = [self getPage:tableView andCurrentpage:_currentPage];
    if ([_answerArr[page-1] intValue] != 0) {
        return;
    }else{
       
        [_answerArr replaceObjectAtIndex:page-1 withObject:[NSString stringWithFormat:@"%ld",indexPath.row+1]];
        
    }
    LeafLevel *leafLevel = [self getModel:tableView];
    if(![leafLevel.mAnswer isEqualToString:[NSString stringWithFormat:@"%c",'A'+(int)indexPath.row]]){
        [QuestionCollect addWrongQuestion:leafLevel.mId];
        //NSLog(@"%@",[QuestionCollect getWrongQuestion]);
    }
    
   [self reloadData];
    
    
    
}

#pragma get answer
-(LeafLevel *)getModel:(UITableView *)tableView
{
    
    LeafLevel *leafLevel;
    //如果为第一页
    if(tableView == _leftTableView && _currentPage == 0){
        leafLevel = _practiseArray[_currentPage];
    }else if(tableView ==_leftTableView && _currentPage>0){
        leafLevel = _practiseArray[_currentPage-1];
    }else if(tableView == _centreTableView && _currentPage == 0 ){
        leafLevel = _practiseArray[_currentPage+1];
    }else if(tableView == _centreTableView && _currentPage>0 && _currentPage<_practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage];
    }else if(tableView == _centreTableView && _currentPage == _practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage-1];
    }else if(tableView == _rightTableView && _currentPage == _practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage];
    }else if(tableView == _rightTableView && _currentPage<_practiseArray.count-1){
        leafLevel = _practiseArray[_currentPage+1];
        
    }
    
   
    return leafLevel;
}



-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor colorWithWhite:0.947 alpha:1.000];
    
    UILabel *label = [[UILabel alloc]init];
    
    LeafLevel *leafLevel = [self getModel:tableView];
    
    label.numberOfLines = 0;
    label.font = [UIFont systemFontOfSize:18];
    label.textColor = [UIColor colorWithRed:0.020 green:0.459 blue:0.000 alpha:1.000];
    
    label.text = [NSString stringWithFormat:@"%@",leafLevel.mDesc];
    CGSize size = [tools sizeWithString:label.text font:label.font];
    
    label.frame = CGRectMake(0, 10, kScreenX, size.height);
    [view addSubview:label];
    
    int page = [self getPage:tableView andCurrentpage:_currentPage];
    if ([_answerArr[page-1] isEqualToString:@"0"]) {
        return nil;
    }
    
    return view;
    
    
    
}


-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    UILabel *label = [[UILabel alloc]init];
    
    LeafLevel *leafLevel = [self getModel:tableView];
    
    
    label.numberOfLines = 0;
    label.font = [UIFont systemFontOfSize:18];
    label.textColor = [UIColor colorWithRed:0.020 green:0.459 blue:0.000 alpha:1.000];
    
    label.text = [NSString stringWithFormat:@"%@",leafLevel.mDesc];
    CGSize size = [tools sizeWithString:label.text font:label.font];
    
    
    
    return size.height+20;
}








@end
