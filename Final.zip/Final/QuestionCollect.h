//
//  QuestionCollect.h
//  Final
//
//  Created by XuanGao on 4/26/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QuestionCollect : NSObject
+(NSArray*)getWrongQuestion;
+(void)addWrongQuestion:(int)mid;
+(void)removeWrongQuestion:(int)mid;
+(NSArray*)getCollectQuestion;
+(void)addCollectQuestion:(int)mid;
+(void)removeCollectQuestion:(int)mid;
@end
