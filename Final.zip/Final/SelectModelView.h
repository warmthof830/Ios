//
//  SelectModelView.h
//  Final
//
//  Created by XuanGao on 4/25/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum {
    testModel,
    lookingModel
}SelectModel;
typedef void (^SelecTouch)(SelectModel model);

@interface SelectModelView : UIView
@property(nonatomic,assign)SelectModel model;
-(SelectModelView*)initWithFrame:(CGRect)frame addTouch:(SelecTouch) touch;

@end
