//
//  SheetView.h
//  Final
//
//  Created by XuanGao on 4/25/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol SheetViewDelegate
-(void)sheetViewClick:(int)index;
@end
@interface SheetView : UIView
{
    @public
    UIView* _backView;
}
@property(nonatomic,weak)id<SheetViewDelegate>delegate;
- (instancetype)initWithFrame:(CGRect)frame withSuperView:(UIView*)superView andQuesCount:(int)count;

@end
