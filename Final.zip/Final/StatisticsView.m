//
//  StatisticsView.m
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "StatisticsView.h"
#define kScreenX [UIScreen      mainScreen].bounds.size.width //screen width
#define kScreenY [UIScreen      mainScreen].bounds.size.height//screen height

@implementation StatisticsView

{
    //UIView *view;
    UIView *_backView;
    UIView *_superView;
    BOOL _startMoving;
    float _height;
    float _width;
    float _y;
}


-(instancetype)initWithFrame:(CGRect)frame withSuperView:(UIView *)superView
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        _height = frame.size.height;
        _width = frame.size.width;
        _y = frame.origin.y;
        _superView = superView;
        
        [self createStatisticsView];
    }
    
    return self;
}




-(void)createStatisticsView
{
    _backView = [[UIView alloc]initWithFrame:_superView.frame];
    _backView.backgroundColor = [UIColor blackColor];
    _backView.alpha = 0;
    
    UIView *centerView = [[UIView alloc]initWithFrame:CGRectMake(0, 10,kScreenX, 40)];
    centerView.backgroundColor = [UIColor grayColor];
    NSArray *arr = @[@"Correct",@"Wrong",@"Not Attempt"];
    for(int i=0;i<3;i++){
        UILabel *label= [[UILabel alloc]init];
        label.frame = CGRectMake(10*(i+1)+80*(i+1), 10, 40, 40);
        label.text = arr[i];
        label.textAlignment = NSTextAlignmentLeft;
        label.textColor = [UIColor blackColor];
        [centerView addSubview:label];
    }
    
    UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 10+50, kScreenX, kScreenY-64-10-40)];
    footView.backgroundColor = [UIColor whiteColor];
    
    
    
    [self addSubview:centerView];
    [self addSubview:footView];
    
    [_superView addSubview:_backView];
    
    
    
    
    
}






-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    //_startMoving = NO;
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:[touch view]];
    
    if (point.y<25) {
        _startMoving = YES;
    }
    if (_startMoving && self.frame.origin.y >= _y-_height && [self convertPoint:point toView:_superView].y>=150) {
        NSLog(@"%f---%f---%f---%f----%f",self.frame.origin.y,_y,_height,[self convertPoint:point toView:_superView].y,point.y);
        self.frame = CGRectMake(0, [self convertPoint:point toView:_superView].y, _width, _height);
        _backView.alpha = 0.9-self.frame.origin.y/1000;
        
    }
    
    
    
}

-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    _startMoving = NO;
    
    if(self.frame.origin.y < _height/2+75){
        [UIView animateWithDuration:0.4 animations:^{
            self.frame=CGRectMake(0, 150, _superView.frame.size.width, _superView.frame.size.height-150);
            
        }];
        _backView.alpha = 0.9-self.frame.origin.y/1000;
        
    }else{
        [UIView animateWithDuration:0.4 animations:^{
            self.frame=CGRectMake(0, _superView.frame.size.height, _superView.frame.size.width, _superView.frame.size.height-150);
            
        }];
        _backView.alpha = 0;
    }
    
    
}




@end
