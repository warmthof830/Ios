//
//  Tools.h
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Tools : NSObject


// 处理字符串
-(NSArray *)getAnsWerWithString:(NSString *)str;
// 获取文本size
-(CGSize)sizeWithString:(NSString *)string font:(UIFont *)font;

@end
