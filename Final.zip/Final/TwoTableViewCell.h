//
//  TwoTableViewCell.h
//  Final
//
//  Created by XuanGao on 4/26/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TwoTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *titleImageView;
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;

@end
