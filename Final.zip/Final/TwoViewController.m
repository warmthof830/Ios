//
//  TwoViewController.m
//  Final
//
//  Created by XuanGao on 4/26/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "TwoViewController.h"
#import "TwoTableViewCell.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
@interface TwoViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView*_tableView;
}

@end

@implementation TwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    _tableView.dataSource=self;
    _tableView.delegate=self;
    [self.view addSubview:_tableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 7;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString*cellID=@"TwoTableViewCell";
    TwoTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:cellID];
    if(cell==nil){
        cell=[[[NSBundle mainBundle]loadNibNamed:cellID owner:self options:nil]lastObject];
    }
    cell.titleImageView.image=[UIImage imageNamed:@"logo.jpg"];
    cell.titleLabel.text=[NSString stringWithFormat:@"vedio:%ld",indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    NSString*path=[[NSBundle mainBundle]pathForResource:@"north" ofType:@"mp4"];
//    NSURL*url=[NSURL fileURLWithPath:path];
    NSURL *url = [NSURL fileURLWithPath:@"/Users/xuan/Desktop/NEU TEST SYSTEM_Xuan_Gao_001220084/Final/north.mp4"];
    
    AVAsset *movieAsset = [AVURLAsset assetWithURL:url];
    AVPlayerItem *playerItem = [AVPlayerItem playerItemWithAsset:movieAsset];
    
    AVPlayer *player = [AVPlayer playerWithPlayerItem:playerItem];
    
    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
    playerLayer.frame = CGRectMake(0, 0, 350, 350);
playerLayer.videoGravity=AVLayerVideoGravityResize;
    
    [self.view.layer addSublayer:playerLayer];
    
    [player play];
//    MPMoviePlayerController *moviePlayer;
//    moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"north" ofType:@"mp4"]]];
//     [moviePlayer play];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
