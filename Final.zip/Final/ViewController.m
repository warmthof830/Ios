//
//  ViewController.m
//  Final
//
//  Created by XuanGao on 4/16/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "ViewController.h"
#import "TwoViewController.h"
#import "WebViewController.h"
#define kScreenX [UIScreen   mainScreen].bounds.size.width
#define kScreenY [UIScreen   mainScreen].bounds.size.height


@interface ViewController ()
{
    UIView *courceView;
    UIButton *oneBtn;
    UIButton *twoBtn;
    UIButton *threeBtn;
    UIButton *fourBtn;
    UIButton *cancelBtn;
}
@property (weak, nonatomic) IBOutlet UIButton *seleCarBtn;
@property (strong, nonatomic) IBOutlet UIButton *twoBtn;
@property (strong, nonatomic) IBOutlet UIButton *introBtn;
@property (strong, nonatomic) IBOutlet UIButton *moreBtn;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)moreBtnClick:(UIButton *)sender {
    UIBarButtonItem *item=[[UIBarButtonItem alloc]init];
    item.title=@"";
    self.navigationItem.backBarButtonItem=item;
    [self.navigationController pushViewController:[[WebViewController alloc]initWithUrl:@"https://google.com"] animated:YES];
}
- (IBAction)twoBtnClick:(UIButton *)sender {
    UIBarButtonItem *item=[[UIBarButtonItem alloc]init];
    item.title=@"";
    self.navigationItem.backBarButtonItem=item;
    [self.navigationController pushViewController:[[TwoViewController alloc]init] animated:YES];
}
- (IBAction)introBtnClick:(UIButton *)sender {
    UIBarButtonItem *item=[[UIBarButtonItem alloc]init];
    item.title=@"";
    self.navigationItem.backBarButtonItem=item;
    [self.navigationController pushViewController:[[WebViewController alloc]initWithUrl:@"https://blackboard.neu.edu"] animated:YES];
    
}

#pragma 选择车型
- (IBAction)changeCar:(id)sender {
    
    [self initWithCarView];
    
    [self setCarsInfo];
}

#pragma 初始化视图
-(void)initWithCarView
{
    
    courceView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenX, kScreenY)];
    [self.view addSubview:courceView];
    [self carAnimation:@"fromTop"];
    
    
    oneBtn = [[UIButton alloc]init];
    [oneBtn addTarget:self action:@selector(didSeleCar:) forControlEvents:UIControlEventTouchUpInside];
    [courceView addSubview:oneBtn];
    
    
    
    
    twoBtn = [[UIButton alloc]init];
    [twoBtn addTarget:self action:@selector(didSeleCar:) forControlEvents:UIControlEventTouchUpInside];
    [courceView addSubview:twoBtn];
    
    threeBtn = [[UIButton alloc]init];
    [threeBtn addTarget:self action:@selector(didSeleCar:) forControlEvents:UIControlEventTouchUpInside];
    [courceView addSubview:threeBtn];
    
    fourBtn = [[UIButton alloc]init];
    [fourBtn addTarget:self action:@selector(didSeleCar:) forControlEvents:UIControlEventTouchUpInside];
    [courceView addSubview:fourBtn];
    
    cancelBtn = [[UIButton alloc]init];
    [cancelBtn addTarget:self action:@selector(cancelSelectCar) forControlEvents:UIControlEventTouchUpInside];
    [courceView addSubview:cancelBtn];
    
    
    
}



#pragma 设置button
-(void)setCarsInfo
{
    
    courceView.backgroundColor = [UIColor colorWithRed:0.123 green:0.125 blue:0.124 alpha:0.900];
    
    oneBtn.frame = CGRectMake(kScreenX/2-kScreenX/5-20, kScreenY/2-20-kScreenX/5, kScreenX/5, kScreenX/5);
    [oneBtn setBackgroundImage:[UIImage imageNamed:@"1"] forState:UIControlStateNormal];
    
    twoBtn.frame = CGRectMake(kScreenX/2+20, kScreenY/2-20-kScreenX/5, kScreenX/5, kScreenX/5);
    [twoBtn setBackgroundImage:[UIImage imageNamed:@"2"] forState:UIControlStateNormal];
    
    threeBtn.frame = CGRectMake(kScreenX/2-kScreenX/5-20, kScreenY/2+20, kScreenX/5, kScreenX/5);
    [threeBtn setBackgroundImage:[UIImage imageNamed:@"3"] forState:UIControlStateNormal];
    
    fourBtn.frame = CGRectMake(kScreenX/2+20, kScreenY/2+20, kScreenX/5, kScreenX/5);
    [fourBtn setBackgroundImage:[UIImage imageNamed:@"4"] forState:UIControlStateNormal];
    
    cancelBtn.frame = CGRectMake(kScreenX/2-20, kScreenY-30-40, 40, 40);
    [cancelBtn setBackgroundImage:[UIImage imageNamed:@"20"] forState:UIControlStateNormal];
    
}





-(void)didSeleCar : (UIButton *)didSeleBtn
{
    [self.seleCarBtn setBackgroundImage:[didSeleBtn currentBackgroundImage] forState:UIControlStateNormal];
    
    [self cancelSelectCar];
}



-(void)cancelSelectCar
{
    
    [self carAnimation:@"fromTop"];
    [courceView removeFromSuperview];
    
}


-(void)carAnimation : (NSString *)animationType;
{
    CATransition *animation = [CATransition animation];
    animation.delegate = self;
    animation.duration = 1;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    animation.type = animationType;

    animation.subtype = kCATransitionPush;
    [courceView.superview.layer addAnimation:animation forKey:@"animation"];
    
}






@end
