//
//  WebViewController.m
//  Final
//
//  Created by XuanGao on 4/27/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController ()
{
    UIWebView*_webView;
}

@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(instancetype)initWithUrl:(NSString*)url{
    self=[super init];
    if(self){
        NSURLRequest*request=[NSURLRequest requestWithURL:[NSURL URLWithString:url]];
        _webView=[[UIWebView alloc]initWithFrame:self.view.frame];
        [_webView loadRequest:request];
        [self.view addSubview:_webView];
    }
    return self;
}
-(instancetype)initWithDeskUrl:(NSString*)url{
    self=[super init];
    if(self){
    _webView=[[UIWebView alloc]initWithFrame:self.view.frame];
    [_webView loadHTMLString:@"<h1>Welcome to NEU Test System</h1>" baseURL:nil];
        _webView=[[UIWebView alloc]initWithFrame:self.view.frame];
        [self.view addSubview:_webView];}
    return self;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
