//
//  chuan.h
//  Final
//
//  Created by XuanGao on 4/26/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface chuan : NSObject
{
    NSString*_contextStr;
}
@property (nonatomic,retain) NSString* contextStr;

+(chuan*)shareInstance;
@end
