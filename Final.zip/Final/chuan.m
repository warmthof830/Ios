//
//  chuan.m
//  Final
//
//  Created by XuanGao on 4/26/17.
//  Copyright © 2017 Xuan Gao. All rights reserved.
//

#import "chuan.h"

@implementation chuan
@synthesize contextStr=_contextStr;
static chuan*_instance=nil;
+(chuan*)shareInstance{
    if(_instance==nil){
        _instance=[[super alloc]init];
    }
    return _instance;
}
-(id)init{
    if(self=[super init]){
        
    }
    return self;
}

@end
